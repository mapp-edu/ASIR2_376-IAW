# entorno-iaw

Entorno de pruebas para Implantación de Aplicaciones Web levantado con Docker Compose:

| Servicio  | Qué es                                   | Dirección               |
|:----------|:-----------------------------------------|:------------------------|
| `web`     | Apache 2 + PHP 8.3 con `pdo_mysql`       | <http://localhost:8080> |
| `db`      | MariaDB 11.4 (solo accesible por dentro) | —                       |
| `adminer` | Administración de la base de datos       | <http://localhost:8081> |

La carpeta `src/` es la raíz web: lo que guardes en ella se ve al momento en el navegador.

## Requisitos

- **Docker** con el plugin **Compose v2** (el comando es `docker compose`, con espacio).
  - Windows y macOS: Docker Desktop.
  - Linux: Docker Engine y el paquete `docker-compose-plugin`.
- Puertos **8080** y **8081** libres.
- Git, para clonar el repositorio.

Comprueba la instalación:

```bash
docker --version
docker compose version
```

## Puesta en marcha

1. Clona el repositorio y entra en la carpeta:

   ```bash
   git clone https://github.com/USUARIO/entorno-iaw.git
   cd entorno-iaw
   ```

2. Crea tu archivo de credenciales a partir de la plantilla:

   ```bash
   cp .env.example .env          # Linux y macOS
   copy .env.example .env        # Windows (cmd o PowerShell)
   ```

3. Edita `.env` y da valor a todas las variables. Ejemplo:

   ```ini
   DB_ROOT_PASSWORD=una-clave-larga-para-root
   DB_NAME=iaw
   DB_USER=iaw_user
   DB_PASSWORD=otra-clave-larga
   TZ_WEB=Europe/Madrid
   ```

   Evita el carácter `$` en las contraseñas: Compose lo interpreta como una variable.

4. Construye la imagen web y levanta los tres servicios:

   ```bash
   docker compose up -d --build
   ```

   La primera vez tarda unos minutos: descarga las imágenes, compila `pdo_mysql` e inicializa la base de datos.

5. Comprueba que todo está en marcha:

   ```bash
   docker compose ps
   ```

   Los tres servicios deben aparecer como `running` y `db` además como `healthy`.

6. Abre <http://localhost:8080/hora.php>. Debes ver la hora del servidor, la del navegador y la versión de MariaDB.

7. Para entrar en Adminer abre <http://localhost:8081> con estos datos:
   - Sistema: **MySQL / MariaDB**
   - Servidor: **db**
   - Usuario y contraseña: los de `DB_USER` y `DB_PASSWORD`
   - Base de datos: la de `DB_NAME`

## Uso diario

| Quiero…                                    | Comando                                   |
|:-------------------------------------------|:------------------------------------------|
| Ver el estado de los servicios             | `docker compose ps`                       |
| Ver los registros (todos, en directo)      | `docker compose logs -f`                  |
| Ver los registros de un servicio           | `docker compose logs web`                 |
| Abrir una terminal en el servidor web      | `docker compose exec web bash`            |
| Abrir el cliente de MariaDB                | `docker compose exec db mariadb -u root -p` |
| Parar sin borrar nada                      | `docker compose stop`                     |
| Volver a arrancar lo parado                | `docker compose start`                    |
| Reiniciar un servicio                      | `docker compose restart web`              |
| Aplicar cambios de `.env` o `docker-compose.yml` | `docker compose up -d`              |
| Aplicar cambios del `Dockerfile`           | `docker compose up -d --build`            |

Los cambios en `src/` no necesitan reiniciar nada: basta con recargar el navegador.

## Parar y borrar el entorno

```bash
docker compose down              # borra contenedores y red; los datos se conservan
docker compose down -v           # además borra el volumen: SE PIERDE LA BASE DE DATOS
docker compose down -v --rmi local   # además borra la imagen web construida
```

## Empezar de cero

Si la base de datos ha quedado en mal estado o has cambiado las credenciales de `.env` después del primer arranque:

```bash
docker compose down -v
docker compose up -d --build
```

MariaDB solo crea la base de datos y el usuario la **primera vez**, con el volumen vacío. Si cambias `DB_NAME`, `DB_USER` o las contraseñas después, no se aplican hasta que borres el volumen.

## Problemas frecuentes

- **`Falta DB_PASSWORD en .env`** (o cualquier otra variable): no existe `.env` o le falta esa línea. Repite los pasos 2 y 3.
- **`port is already allocated`**: otro programa usa el 8080 o el 8081 (XAMPP, otro entorno…). Páralo o cambia el puerto de la izquierda en `docker-compose.yml`, por ejemplo `"8090:80"`.
- **La página dice «No se ha podido conectar con la base de datos»**: mira el motivo con `docker compose logs web db`. Lo habitual es haber cambiado credenciales sin borrar el volumen (ver «Empezar de cero»).
- **`web` no arranca y se queda esperando**: espera a que `db` esté `healthy`; la primera inicialización tarda unos segundos.
- **Linux: `permission denied` al usar docker**: añade tu usuario al grupo `docker` (`sudo usermod -aG docker $USER`) y vuelve a iniciar sesión.

## Estructura

```
entorno-iaw/
├── docker-compose.yml   # definición de los tres servicios
├── Dockerfile           # imagen web: php:8.3-apache + pdo_mysql + zona horaria
├── .env.example         # plantilla de variables (sin valores)
├── .env                 # tus credenciales (no se sube: está en .gitignore)
├── .gitignore
└── src/                 # raíz web
    ├── index.php        # redirige a hora.php
    └── hora.php         # hora del servidor y del navegador + versión de MariaDB
```
